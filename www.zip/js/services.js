angular.module('starter.services', [])

.service('DataService',['$window','$http','$rootScope',function($window , $http , $rootScope) {
	
	this.get = function(localname , endpoint , input , success_cb , failed_cb , skip_cache) {
		
		var h = { 'Content-Type': 'application/json' };
		
		if (!skip_cache) {
			
			if (localStorage.getItem(localname) == null) {
				skip_cache = true;
			} else {
				
				//If we have the data, but we feel that this data is to old, we should rather go fetch from the server...
				// TODO : make session timeout variable

				$rootScope.$broadcast(success_cb,{
        			'success': true,
        			'data': JSON.parse(localStorage.getItem(localname))
        		});
				
				skip_cache = false;
				
			}
			
		}

		if (skip_cache) {
			$http.post(endpoint, input, { headers: h }).
	        	then(function(response) {
	        		
	        		//save to cache for use later
	        		
	        		if (localname != '') {
	        			localStorage.setItem(localname,JSON.stringify(response.data));
	        		}
	        		
	        		$rootScope.$broadcast(success_cb,{
	        			'success': true,
	        			'data': response.data
	        		});
	        	
	        	}, function(response) {
	        	
	        		$rootScope.$broadcast(failed_cb,{
	        			'success': false,
	        			'data': response.data
	        		});
	        	
	        	}
	        
	        );
			
		};
	}
	
	this.setlocal = function(name,value) {
		localStorage.setItem(name,value);
	};
	
	this.getlocal = function(name) {
		return localStorage.getItem(name);
	}
	
	this.clearCache = function() {
		localStorage.clear();
	}
	
	
	
}]);