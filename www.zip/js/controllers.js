angular.module('starter.controllers', ['starter.services'])

.controller('AppCtrl', function($scope, $ionicModal, $timeout, DataService, $ionicLoading, $ionicPopup, $location, $state) {

	// With the new view caching in Ionic, Controllers are only called
	// when they are recreated or on app start, instead of every page change.
	// To listen for when this page is active (for example, to refresh data),
	// listen for the $ionicView.enter event:
	//$scope.$on('$ionicView.enter', function(e) {
	//});

	$scope.user = {
		id				: 0,
		email 			: '',
		password 		: '',
	};
	
	$scope.requests = [];
	
	// Create the login modal that we will use later
	$ionicModal.fromTemplateUrl('templates/login.html', {
		scope: $scope
	}).then(function(modal) {
		$scope.modal = modal;
	});

	// Triggered in the login modal to close it
	$scope.closeLogin = function() {
		$scope.modal.hide();
	};

	// Open the login modal
	$scope.login = function() {
		$scope.modal.show();
	};
	
	$scope.logout = function() {
		DataService.clearCache();
		$scope.reset();
		$state.go('app.dashboard');
	}
	
	$scope.showAlert = function() {
		var alertPopup = $ionicPopup.alert({
		     title: 'Don\'t eat that!',
		     template: 'It might taste good'
		});

		alertPopup.then(function(res) {
		});
	};
  
	/*********************************************************************************************
	 * Login Data Calls
	 */
  
  	$scope.$on('login-success',function(event,data) {
  		$scope.user = data.data.data.user;
  		$ionicLoading.hide();
  		$scope.closeLogin();
  		$scope.$broadcast("getActiveSessions", {});
  	});

	$scope.$on('login-failed',function(event,data) {
		$ionicLoading.hide();
	});

	// Perform the login action when the user submits the login form
	$scope.doLogin = function() {
		$ionicLoading.show({ template: 'Please wait...' });
		DataService.get(
			  'user',
			  endpoint + 'login/login',
			  { loginemail : $scope.user.email, loginpassword : $scope.user.password },
			  'login-success',
			  'login-failed',
			  true
		);
	};
	
	/**
	 * End Login Data Calls
	 *********************************************************************************************/
	
	angular.element(document).ready(function() {
		
		//Check if user is logged in and get user details
		data = JSON.parse(DataService.getlocal('user'));
		if (data != null) {
			$scope.user = data.data.user;
		}
		
	});
	
	$scope.GoToSession = function(session) {
		DataService.setlocal('activesession',JSON.stringify(session));
		$state.go('app.session');
	};
	
	$scope.reset = function() {
		$scope.user = {
				id				: 0,
				email 			: '',
				password 		: '',
			};
		
		$scope.requests = [];
	};
  
})

.controller('ProfileCtrl', function($scope) {
})

.controller('SettingsCtrl', function($scope, $stateParams) {
})

.controller('SessionCtrl', function($scope, $stateParams, $state, $ionicLoading, DataService, $ionicModal, $ionicPopup) {
	
	$scope.myorder = {};
	$scope.session = {};
	
	$scope.view = 0;

	$scope.menu = {};
	$scope.menuitem = {};
	
	$scope.orderitem = {}; 				//this is the variable that gets pushed through to the order
	
	/*********************************************************************************************
	 * Get Menu
	 */
  
  	$scope.$on('get-menu-success',function(event,data) {
  		$scope.menu = data.data.data;
  		$ionicLoading.hide();
  		$scope.$broadcast('scroll.refreshComplete');
  	});

	$scope.$on('get-menu-failed',function(event,data) {
		$ionicLoading.hide();
	});

	// Perform the login action when the user submits the login form
	$scope.GetMenu = function() {
		
		$ionicLoading.show({ template: 'Loading Sessions...' });
		
		DataService.get(
			  'menu',
			  endpoint + 'menu/list',
			  { restaurant_branch_id : 1 },
			  'get-menu-success',
			  'set-menu-failed',
			  true
		);
		
	};
	
	$scope.GetMenu();
	
	
	/**
	 * End Get Session
	 *********************************************************************************************/
	
	/*********************************************************************************************
	 * Get My Order
	 */
  
  	$scope.$on('get-my-order-success',function(event,data) {
  		$scope.myorder = data.data.data;
  		console.log("Order : ",$scope.myorder);
  	});

	$scope.$on('get-my-order-failed',function(event,data) {
	});

	// Perform the login action when the user submits the login form
	$scope.GetOrder = function() {
		
		DataService.get(
			  'order',
			  endpoint + 'order/get',
			  { session_id : 1 , user_id : $scope.user.id },
			  'get-my-order-success',
			  'set-my-order-failed',
			  true
		);
		
	};
	
	$scope.GetOrder();
	
	
	/**
	 * End Get Session
	 *********************************************************************************************/

	$scope.OpenMenuItem = function(item) {
		$scope.menuitem = item;
		$scope.orderitem = {};
		//alert(id);
		$scope.modal.show();
	}
	
	// Create the login modal that we will use later
	$ionicModal.fromTemplateUrl('templates/menuitem.html', {
		scope: $scope
	}).then(function(modal) {
		$scope.modal = modal;
	});

	// Triggered in the login modal to close it
	$scope.closeLogin = function() {
		$scope.modal.hide();
	};
	
	$scope.$on('place-order-success',function() {
		$ionicLoading.hide();
		$scope.modal.hide();
		
		var alertPopup = $ionicPopup.alert({
			title: 'Thank you!',
			template: 'Item added to order!'	
		});

		$scope.GetOrder();
		
	});
	
	$scope.PlaceOrder = function() {
		
		$ionicLoading.show({ template: 'Adding to order...' });
		
		DataService.get(
			'',
			endpoint + '/order/add',
			{ order_id:1 , user_id:$scope.user.id , item:JSON.stringify($scope.orderitem)},
			'place-order-success',								
			'place-order-failed',
			true					
		);
		
	};

})

.controller('DashboardCtrl', function($scope , DataService , $ionicLoading, $state, $rootScope) {
	
	$scope.sessions = {};
	
	/*********************************************************************************************
	 * Get Sessions
	 */
  
  	$scope.$on('get-sessions-success',function(event,data) {
  		$scope.sessions = data.data.data.data;
  		$ionicLoading.hide();
  		$scope.$broadcast('scroll.refreshComplete');
  	});

	$scope.$on('get-sessions-failed',function(event,data) {
		$ionicLoading.hide();
	});

	// Perform the login action when the user submits the login form
	$scope.GetActiveSessions = function() {
		
		if ($scope.user.id > 0) {
			
			$ionicLoading.show({ template: 'Loading Sessions...' });
		
			DataService.get(
				  'sessions',
				  endpoint + 'session/getactivesessions',
				  { userid : $scope.user.id },
				  'get-sessions-success',
				  'set-sessions-failed',
				  true
			);
		
		}
	};
	
	$scope.$on("getActiveSessions", function (event, args) {
		$scope.GetActiveSessions();
	});
	
	/**
	 * End Get Session
	 *********************************************************************************************/
	
	angular.element(document).ready(function() {
		
		$scope.$broadcast("getActiveSessions", {});

		//$state.go('app.session');

	});
	
	$scope.$on('session-checkin-success',function(event , data) {
		
		$scope.GetActiveSessions();
		$ionicLoading.hide();
		$state.go('app.session');
		
	});
	
	$scope.$on('session-checkin-failed',function(event , data) {
		$ionicLoading.hide();
	});
	
	$scope.Checkin = function() {
		
		$ionicLoading.show({ template: 'Checkin - Please wait...' });
		
		DataService.get(
				'activesession',
				endpoint + 'session/checkin',
				{ restaurant_id : 1, restaurant_branch_id : 1 , restaurant_branch_table_id : 1 , user_id : $scope.user.id },
				'session-checkin-success',
				'session-checkin-failed',
				true
		);
		
	};
	
	
})

;
